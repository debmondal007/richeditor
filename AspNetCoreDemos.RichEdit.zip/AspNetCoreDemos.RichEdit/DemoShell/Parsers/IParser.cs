﻿namespace AspNetCoreDemos.DemoShell {
    public interface IParser {
        string Parse(string text);
    }
}
