The DevExpress Web Rich Text Editor is a client control that you can use in different client and server frameworks. The control allows you to create, open, modify, print, save, and convert rich-formatted text files.

These demos show how to add and customize the RichEdit control in an ASP.NET Core application.