﻿using AspNetCoreDemos.RichEdit.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Data.SqlClient;

namespace AspNetCoreDemos.RichEdit {

    [Route("[action]")]
    public class RichEditController : Controller {
        private const string documentFolderPath = "~/Documents/";
        string con = "Data source=.; Database=TestDB;User Id=sa;Password=Sync#150";
        public IActionResult Overview() {
            return View();
        }
        // Document Managment
        #region LoadAndSave
        public IActionResult LoadAndSave() {
            byte[] data = System.IO.File.ReadAllBytes("D:\\old\\sample-1.rtf");
            RichEditFile richEditFile = new RichEditFile();
            richEditFile.Data= data;
          

            using (SqlConnection myConnection = new SqlConnection(con))
            {
                string oString = "Select top 1 * from RichEditorTable";
                SqlCommand oCmd = new SqlCommand(oString, myConnection);
                 myConnection.Open();
                using (SqlDataReader oReader = oCmd.ExecuteReader())
                {
                    while (oReader.Read())
                    {
                        richEditFile.fileName = oReader["Name"].ToString();
                        richEditFile.Data =(byte[]) oReader["FileContent"];
                        richEditFile.Id = Convert.ToInt32(oReader["Id"].ToString());
                    }

                    myConnection.Close();
                }
            }


            return View(richEditFile);
        }

        public IActionResult Export(string base64, string fileName, DevExpress.AspNetCore.RichEdit.DocumentFormat format,int Id) {
           string query = "";
            try
            {
                byte[] fileContents = System.Convert.FromBase64String(base64);

                SqlConnection connection = new SqlConnection(con);
               // SqlConnection connection = new SqlConnection(@connectionString);
               if(Id>0)
                {
                    query = "update RichEditorTable set  FileContent= @FileContent where Id=@Id";
                }
                 else
                    query = "INSERT INTO RichEditorTable (Name, FileContent) VALUES(@Name, @FileContent)";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@Id", Id);
                command.Parameters.AddWithValue("@Name","TestFile");
                command.Parameters.AddWithValue("@FileContent", fileContents);


                connection.Open();
                command.ExecuteNonQuery();
                Console.WriteLine("Records Inserted Successfully");
            }
            catch (Exception e)
            {
                Console.WriteLine("Exception Occre while creating table:" + e.Message + "\t" + e.GetType());
            }
            return Ok();
        }

        public IActionResult DocumentProtection() {
            return View();
        }
        #endregion

        //Templates
        public IActionResult DynamicContent() {
            return View();
        }
        public IActionResult MailMerge() {
            return View();
        }

        //Features
        public IActionResult Autocorrect() {
            return View();
        }

        //Customization
        public IActionResult SimpleView() {
            return View();
        }
        public IActionResult RibbonCustomization() {
            return View();
        }
        public IActionResult ContextMenuCustomization() {
            return View();
        }
    }
}
